 function PSNR = calcPSNR(x1,x2,maxX)
% This function takes two column vectors (x1, x2) and a maximum value for 
% their elements (maxX) as inputs and calculates their Peak Signal-to-Noise Ratio 
% (PSNR) (use Eq. 2). It assigns the calculated value to the output 
% variable PSNR. 
%
% Inputs: x1,x2 which are two column vectors; and maxX, the maximum value
% for their elements
% Ouput: PSNR, the two vectors' Peak Signal-to-Noise Ratio

if ~exist('maxX','var') | isempty(maxX);
    maxX=1;
end
MSE=calcMSE(x1,x2);

if MSE==0;
    PSNR=100;
else
    PSNR=10*log10((maxX^2)/MSE);
end