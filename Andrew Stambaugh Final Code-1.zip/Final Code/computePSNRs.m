 function PSNRs = computePSNRs(imgVec, imageDatabase) 
 % This function takes a vectorized image (imgVec) and a database matrix of 
 % vectorized images (imageDatabase) as inputs and computes the PSNR 
 % between imgVec and each image (column) in the database matrix. Then each
 % PSNR is stored into an array (PSNRs)
 %
 % Inputs: imgVec, vectorized image; imageDatabase, database matrix containing
 % vectorized images as columns
 % Output: PSNRs, a column vector cotaining all of the PSNR's between
 % imgVec and every image in imadeDatabase
 
 cols=size(imageDatabase,2);
 PSNRs=zeros(1,cols)
 for ii = (1:cols)
    x1 = imageDatabase(:,ii);
    psnr = calcPSNR(imgVec,x1);
    PSNRs(1,ii)= psnr;
 end
     