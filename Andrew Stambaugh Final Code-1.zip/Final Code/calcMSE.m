function MSE = calcMSE(x1,x2) 
% This function takes two column vectors (x1, x2) as inputs, calculates 
% their Mean Squared Error (MSE) (use Eq. 1) and assigns the result to the
% output variable MSE
%
% Inputs: x1, x2, both column vectors
% Output: MSE, Mean Squared Error of the two column vectors

%check if the two inputs are both column vectors
x1=makeVector(x1);
x2=makeVector(x2);
M=size(x1,1);

MSE=(1/M)*sum((x1-x2).^2);

