function minPos = findMinimumErrorPosition(imgVec, imageDatabase) 
% This function takes a vectorized image (imgVec) and a database matrix of 
% vectorized images (imageDatabase) as inputs and ?nds the position 
% (column index) of the vectorized image in the database matrix that produces
% the smallest MSE with the input imgVec. The result (column index) is 
% assigned to the output minPos.
% 
% Inputs: imgVec, vectorized image; imageDatabase, database matrix
% containing vectorized images as columns
% Output: minPos, the column of imageDatabase that produces the smallest
% MSE with imgVec

cols= size(imageDatabase,2);

% Must set a matrix of zeros for dimensions of MSEs
MSEs = zeros(1,cols);

 for ii = (1:cols)
    image = imageDatabase(:,ii);
    mse = calcMSE(imgVec,image);
    MSEs(1,ii)= mse;
 end
 
 %Find minimum value in MSEs vector
 minMSE = min(MSEs,[],'all');
 
 %Find position where minMSE is reached
 for ii = [1:cols]
     if minMSE == MSEs(1,ii)
         minPos=ii;
         return
     end
 end


    