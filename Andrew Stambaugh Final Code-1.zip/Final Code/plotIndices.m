 function plotIndices(scrambledIndices, correctIndices) 
 % This function takes the scrambledIndices and the correctIndices as 
 % inputs and creates a ?gure with two plots of the indices for comparison
 
 % Inputs: scrambledIndices, the scrambled indices of the player images in
 % the database; correctIndices, the correct indices of the player images
 % in order.
 %
 % Output: the two plots of the input arrays in a single figure
figure
subplot(2,1,1)
x1=1:100;
y1=scrambledIndices;
plot(x1,y1,'o')
 xlabel('Player ID')
 ylabel('Database Column')
 xlim([0 100])
 ylim([0 100])
 axis square
subplot(2,1,2)
x2=1:100;
y2=correctIndices;
plot(x2,y2,'o')
 xlabel('Player ID')
 ylabel('Database Column')
 xlim([0 100])
 ylim([0 100])
 axis square
 